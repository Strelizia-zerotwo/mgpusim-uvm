# 验证记录：INV / I-1 oracle 实验

验证日期：2026-10-16。均为模拟器结果，不是实卡测量。

## 编译和检查

- `go build ./...`：通过。
- `go test -race -p 2`：replica、faultvm、localmapping、rdma、driver、cp、runner 子包通过，日志 `results/replica-development/race-tests-final.log`。
- 完整四 GPU probe 的 race 二进制 replay：通过，无 DATA RACE；日志 `results/replica-development/race-replay/run-final.log`。
- 全仓库 `golangci-lint run ./... --timeout=10m`：0 issues，日志 `results/replica-development/lint-final.log`。
- 离线分析器测试通过，包含已有副本 vs 无副本的 S3 区分及读/脏交集检查。
- 原有映射缺页基线全套运行通过：两/四 GPU FIR、SC、bitonicsort，有限主机队列拥塞、反压、RDMA、共享时序和功能仿真、已移除选项的拒绝。完整证据 `results/uvm-validation-20261016-020024/validation.json`。

## 端到端对照

默认固定 copy-fault = 900 ns；带宽 300 GB/s；传播 200 ns。

| 负载 | INV 时间/us | I-1 时间/us | 端到端节省 | INV 复制/B | I-1 复制/B | S3 已有副本读取 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| probe | 68.620000 | 63.592000 | 7.327310% | 36864 | 12576 | 24 |
| fw | 462.798000 | 462.798000 | 0.000000% | 0 | 0 | 0 |
| stencil | 506.408000 | 506.381000 | 0.005332% | 73728 | 64512 | 0 |
| 64k | 70.650000 | 64.394000 | 8.854919% | 589824 | 196896 | 24 |

probe 是专门检验机制的人造负载。FW(32 nodes,8 passes) 和 stencil(34x66,8 iterations) 是现有单 GPU 内核的阶段间轮换调度；不能称为分区并行四 GPU benchmark，也不能把 probe 收益推广到正式应用。

probe 的逐级对照中，S1/字节减少只带来很小的端到端变化，I-1 的主要变化来自写阶段允许读取不冲突的已有副本。FW 没有发生复制，收益为零；stencil 的字节减少几乎没有影响总时间。目前没有“多数规范应用超过20%”的证据。

额外验证：64 KiB 页、每GPU仅1个副本帧预算(6次实际回收)、非home GPU写入，以及I-infinity写副本后的免费功能合并均通过数值校验。已扫900/20000 ns，以及成对 infinite BW / zero copy-fault 灵敏度。所有已完成结果满足时间守恒。

## 结果索引

- probe: `results/replica-recovery/probe/2026-10-16_02-00-24_5a06d1`
- fw: `results/replica-recovery/fw/2026-10-16_02-02-43_ca7b90`
- stencil: `results/replica-recovery/stencil/2026-10-16_02-02-57_7ccbc3`
- capacity: `results/replica-recovery/probe/2026-10-16_02-07-40_84105f`
- 64k: `results/replica-recovery/probe/2026-10-16_02-02-51_72f306`
- i2-budget: `results/replica-recovery/probe/2026-10-16_02-03-08_bf07ac`
- remote-writer: `results/replica-recovery/probe/2026-10-16_02-04-05_f71612`

## 边界

当前实现是 oracle 驱动的 kernel-barrier INV / I-1；原有 demand 保持映射缺页含义。不是完整内核内权限故障/复制协议，也未实现GPS写更新、元数据缓存与溢出、真实副本DMA对DRAM控制器的逐请求竞争。`i2` 只是参数化成本预算，不能叫完整I-2。物理缓存flush/invalidate为各模式共同支付的保守屏障成本；TLB/PTE元数据修改在oracle下免费。S4只报告撤销目标，不给零shootdown的INV凭空加成本。

最后补充的 S3 回归检查确认：因容量压力被驱逐的副本不会被 shadow INV 当作仍然有效的副本；`go test -race ./amd/timing/replica` 与最终全仓 lint 再次通过。
