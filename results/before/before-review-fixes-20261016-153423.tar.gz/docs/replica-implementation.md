# Oracle 页面复制实验：实现与操作

工作目录：`/home/only/projects/mgpusim-uvm`。

## 两遍执行

1. 从当前源码构建 `amd/samples/replica`。
2. 记录真实时序内核在地址翻译器入口产生的 virtual read / write。仅记录注册的统一内存数据页，使用 dirty byte mask 聚合写子块。
3. 输出 `record/observed-plan.json`，每阶段保留每 GPU、每页的读掩码、写掩码及 transaction 数；阶段为显式全局屏障。
4. 以同一份 plan 和相同数据重跑各策略。每个请求都检查是否在 plan 中，是否非法写入副本，以及读取的子块版本是否过期；阶段结束再次核对实际读写集。
5. 正常执行的数值校验必须通过；没有捕获到任何 managed access 会失败。结果含完整命令、配置、源码 SHA256、实际再观察 plan、SQLite 和统计 JSON。

## 一键运行

```bash
cd /home/only/projects/mgpusim-uvm
python3 benchmark/replica-recovery/run.py
python3 benchmark/replica-recovery/run.py --sensitivity
python3 benchmark/replica-recovery/run.py --page-bytes 65536 --policies inv,i1 --fault-ns 900
python3 benchmark/replica-recovery/run.py --probe-pages 2 --replica-pages-per-gpu 1 --policies inv,i1 --fault-ns 900
```

默认策略为 NoRep、INV、S1、S1+S2、I-1、I-infinity，默认 fixed copy-fault 扫 900 / 20000 ns。
`--sensitivity` 增加成对 INV/I-1 的 infinite bandwidth 与 zero copy-fault 对照。带宽为零是显式“无穷带宽”哨兵，传播延迟仍存在。

普通 NoRep 的 copy-fault 数为零；其原有 faultvm 映射缺页仍由 `-vm-*` 参数控制。因此仅改变 copy-fault 参数不会改变 NoRep 的 mapping-fault 服务时间。

## 应用边界

```bash
python3 benchmark/replica-recovery/run.py --workload fw --size 32 --iterations 8 --policies inv,i1
python3 benchmark/replica-recovery/run.py --workload stencil --size 34 --iterations 8 --policies inv,i1
```

FW 和 SHOC stencil2d 的现有内核本来就是单 GPU 迭代；该入口在阶段间轮换选定 GPU。它们执行真实应用内核并做 CPU 数值校验，但 **不等于** 分区并行四 GPU FW/stencil。默认 sample 的执行方式不变，只有新入口显式启用这些 hooks。

probe 是检验状态转换的人造机制负载。包含冷复制、同阶段写脏/读干净、干净复用、脏复用、累积写和按需差量修复；两页模式额外验证驱逐与重新分配。probe 上的加速不用于证明正式应用普遍获益。

## 结果

`results/replica-recovery/<workload>/<时间_唯一ID>/summary.tsv` 与 `summary.json` 汇总各模式。

- `application_ps = kernel_ps + barrier_flush_ps + recovery_wait_ps`，脚本强制检查守恒。
- `copy_bytes` 包括冷复制，`recovery_events` 逐次记录 cold/refill/repair 的源版本、字节、起止时间、32/128/512/4096 粒度的块数和连续区间。
- `s3_preexisting_replica_read_transactions` 以独立的 INV shadow 状态判断“失效前已有有效副本”，不包含从未持有副本的 GPU。
- `s3_conflicting_read_sectors` 正常有效 plan 应为零；发现实际冲突在运行前拒绝。
- `fabric_bytes` 包含普通 RDMA、复制及消息头。`copy_bytes` 仅计副本 payload。
- `peak_replica_pages`、`peak_stale_pages` 和 `evictions` 单独计显存成本。

端到端节省为 `(INV.application_ps - I1.application_ps) / INV.application_ps`，不能把复制流量减少百分比写成程序加速。

## 原有离线分析器

`benchmark/replica-recovery/analyzer` 从旧工程独立复制到本目录。它读取旧式 `<prefix>.bin/.meta`，不修改旧目录。

```bash
cd /home/only/projects/mgpusim-uvm/benchmark/replica-recovery/analyzer
/usr/local/go/bin/go run . -trace /path/to/trace -pages 4096 -grans 32,128,512,4096 -json /path/to/result.json
```

已保留每页每 GPU 的读子块，并修正 S3 为已有有效副本的无冲突读取。混有读写冲突或多个写者的 page-epoch 不擅自算收益，而计入 ambiguous；报告 reread dirty/clean sectors 和失效数。对于旧式聚合 trace，只能把整组读取都无冲突的 transaction 算入 S3；混合组无法精确拆分，必须报告歧义。

原工程当前 FW/stencil 结果目录只剩 `.meta` 和旧 summary，没有原始 `.bin`，故没有重新宣称其 21504 / 122165 次 remote tx 的精确 S3 数。本次新入口生成的是完整 JSON plan。

## 代码入口

- `amd/timing/replica`：plan、每 GPU 页面副本状态、版本/有效位、策略、传输预算和 request guard。
- `amd/driver/replicabarrier.go`：实际帧分配/回收、公共 cache flush、模拟时间推进。
- `amd/timing/localmapping/barrier.go`：全局排空后允许不同 GPU 使用不同物理帧的页表视图。
- `amd/timing/rdma/fabric.go`：可选延迟/带宽预算；原 demand 模式未 attach 时不启用。
- `amd/samples/replica`：明确的 oracle sample；普通 FIR/SC 等入口不自动启用复制。

保留限制：没有 kernel 内部写保护缺页、硬件 PTE 子块权限、实际元数据记录硬件、原子一致性、系统级跨 GPU 同步、迁移或 OS swap。oracle 子块有效性由 plan 和逐请求检查执行，而不是宣称已有真实硬件 TLB 子块保护。

额外修复：完整 race 运行揭示旧驱动使用 `Pause(); TickLater(); Continue()` 时仍会与当前 engine event 竞争。现在 host wakeup 与 engine.Run 共用 engineMutex；这避免并发修改非线程安全的时钟/事件堆。
