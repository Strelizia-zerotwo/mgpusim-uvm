# INV 页面复制基线配置单

入口：`benchmark/replica-recovery/run.py`，不是对任意现有 sample 加一个参数就自动支持复制。

```bash
cd /home/only/projects/mgpusim-uvm
python3 benchmark/replica-recovery/run.py --policies inv --fault-ns 900,20000
```

源配置：`benchmark/replica-recovery/configs/inv.json`。每轮实际 JSON 和命令保存在对应结果目录。

| 项目 | INV 配置 |
| --- | --- |
| 底层模式 | `-timing -vm-mode=demand -use-unified-memory`，独立 GPU |
| GPU | 默认 1,2,3,4；保留现有 AMD r9nano 时序模型，64 CU/GPU |
| 物理显存 | 现有平台默认 4 GiB/GPU；不等于此前论文的 70% 应用占用设置 |
| 数据粒度 | 默认 4096 B 页；支持 `--page-bytes 65536`，同时改变分配器、MMU、TLB 页大小 |
| 权威数据 | 原有统一内存物理页，通常位于 GPU1；权威位置固定 |
| 并发限定 | 全局显式 kernel barrier；每阶段每页最多一个写者；跨 GPU 读写的 32 B 子块不能重叠 |
| 初始副本 | 无，GPU 的首次只读阶段为其分配本地物理帧并复制整页 |
| 写阶段 | oracle 在启动写阶段前撤销整页副本并回收帧；该阶段其他 GPU 访问权威页 |
| 再次读取 | 下一次只读阶段重新分配帧，整页复制；已有效的副本不会重复复制 |
| 实际功能 | 分离的物理帧、真实数据复制、每 GPU 不同 PTE；执行真实 GCN3 内核并检查输出 |
| 缺页固定服务 | 默认 900 ns，每个 GPU/page 复制事件计一次；必须同时扫 20000 ns |
| 服务并发 | 16 个固定开销服务槽；同阶段同 GPU 同页请求由 plan 合为一次准备事件 |
| 数据传输 | 默认 300 GB/s（十进制）、200 ns 单向传播；包含 16 B 消息头 |
| 竞争 | 普通远端 RDMA 和复制共用 source injection / destination receive 带宽预算 |
| 目录、PTE 安装、TLB 清理 | oracle 理想化为零时间；在全局排空后完成 |
| 缓存 | 每阶段结束都实际 drain / flush / invalidate L1/L2，写回真实数据；所有比较模式支付同样规则的开销 |
| 显存 | 副本使用真实帧；默认不额外限制副本预算；`--replica-pages-per-gpu N` 启用预算和 LRU 回收 |
| 容量不足 | 当前阶段已 pin 的页不能被换出；无法分配的读取回退到权威页远端访问 |
| 时间分母 | `application_ps`：第一阶段准备开始至最后阶段提交完成，包含内核、恢复等待和公共缓存屏障 |

注意：这是 **oracle 驱动、在阶段开始前准备的 INV**。没有实现内核中途的写保护缺页、permission fault handler 或硬件目录协议。原有 faultvm 仍为普通映射提供本地 GMMU / HostMMU；复制缺页的固定开销由 barrier coordinator 的有限服务槽计时。

互连是延迟/带宽抽象，不是完整 NVSwitch/NVLink 路由模型。副本 payload 通过 backing storage 功能性复制，并按实际字节数预留传输预算；没有把副本 DMA 变成所有 DRAM 控制器中的逐条读写请求。预算不等于整机 DRAM oversubscription；没有 OS migration。
