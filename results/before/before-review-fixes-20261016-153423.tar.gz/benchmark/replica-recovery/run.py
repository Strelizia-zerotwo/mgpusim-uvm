#!/usr/bin/env python3
"""Build, record actual kernel requests, replay matched replication policies."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import uuid

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "mgpusim"


def dump(path, obj):
    path.write_text(json.dumps(obj, indent=2, allow_nan=False) + "\n")


def execute(cmd, directory):
    directory.mkdir(parents=True, exist_ok=True)
    dump(directory / "command.json", cmd)
    with (directory / "run.log").open("w") as log:
        result = subprocess.run(cmd, cwd=directory, stdout=log, stderr=subprocess.STDOUT)
    if result.returncode:
        print((directory / "run.log").read_text(), flush=True)
        raise RuntimeError(f"simulation failed ({result.returncode}): {directory}")
    if "Passed!" not in (directory / "run.log").read_text():
        raise RuntimeError(f"missing numerical verification: {directory}")
    stats = json.loads((directory / "stats.json").read_text())
    if not stats["epochs"]:
        raise RuntimeError("no executed epochs")
    if stats["application_ps"] != sum(stats[k] for k in ("kernel_ps", "barrier_flush_ps", "recovery_wait_ps")):
        raise RuntimeError("elapsed-time accounting mismatch")
    return stats


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--workload", choices=["probe", "fw", "stencil"], default="probe")
    ap.add_argument("--gpus", default="1,2,3,4")
    ap.add_argument("--size", type=int, default=32)
    ap.add_argument("--iterations", type=int, default=8)
    ap.add_argument("--page-bytes", type=int, default=4096)
    ap.add_argument("--probe-pages", type=int, choices=[1, 2], default=1)
    ap.add_argument("--fault-ns", default="900,20000")
    ap.add_argument("--policies", default="norep,inv,retain,i1-no-s3,i1,infinity")
    ap.add_argument("--replica-pages-per-gpu", type=int, default=0)
    ap.add_argument("--transfer-gran-bytes", type=int, default=32)
    ap.add_argument("--bandwidth-gbs", type=float, default=300)
    ap.add_argument("--link-ns", type=int, default=200)
    ap.add_argument("--sensitivity", action="store_true", help="Matched INV/I1 pairs with infinite bandwidth and zero copy-fault cost")
    args = ap.parse_args()
    go = shutil.which("go") or "/usr/local/go/bin/go"
    run = ROOT / "results" / "replica-recovery" / args.workload / (
        datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S") + "_" + uuid.uuid4().hex[:6])
    run.mkdir(parents=True)
    binary = run / "replica"
    print(f"Results: {run}", flush=True)
    subprocess.run([go, "build", "-o", str(binary), "./amd/samples/replica"], cwd=SOURCE, check=True)
    common = [str(binary), "-timing", "-disable-rtm", "-use-unified-memory", "-vm-mode=demand", "-verify",
              f"-gpus={args.gpus}", f"-workload={args.workload}", f"-size={args.size}",
              f"-iterations={args.iterations}", f"-page-bytes={args.page_bytes}", f"-probe-pages={args.probe_pages}",
              "-metric-file-name=metrics", "-report-all", "-replica-plan-out=observed-plan.json", "-replica-stats=stats.json"]
    cfg = json.loads((ROOT / "benchmark/replica-recovery/configs/inv.json").read_text())
    cfg.update(page_bytes=args.page_bytes, transfer_gran_bytes=args.transfer_gran_bytes,
               bandwidth_gbs=args.bandwidth_gbs, link_ns=args.link_ns,
               replica_pages_per_gpu=args.replica_pages_per_gpu)
    hashes = {}
    for directory in [SOURCE / "amd", ROOT / "akita-patched"]:
        for path in sorted(directory.rglob("*.go")):
            hashes[str(path.relative_to(ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()
    dump(run / "source-sha256.json", hashes)
    dump(run / "manifest.json", {"arguments": vars(args), "go": subprocess.check_output([go, "version"], text=True).strip(),
                                 "scope": "explicit global barriers; probe or rotating kernels; not concurrent partitioned FW/stencil"})
    record = run / "record"
    record.mkdir()
    record_cfg = {**cfg, "policy": "norep"}
    dump(record / "config.json", record_cfg)
    execute(common + [f"-replica-config={record / 'config.json'}"], record)
    plan = record / "observed-plan.json"
    plan_data = json.loads(plan.read_text())
    if not sum(len(e["accesses"] or []) for e in plan_data["epochs"]):
        raise RuntimeError("empty plan")
    rows = []
    cases = []
    for fault in [int(x) for x in args.fault_ns.split(",")]:
        for policy in args.policies.split(","):
            cases.append((f"{policy}_fault-{fault}ns", {**cfg, "policy": policy, "fault_ns": fault}))
    if args.sensitivity:
        for policy in ["inv", "i1"]:
            cases.append((f"{policy}_infinite-bw", {**cfg, "policy": policy, "bandwidth_gbs": 0}))
            cases.append((f"{policy}_zero-fault", {**cfg, "policy": policy, "fault_ns": 0}))
    for name, case in cases:
        if case["policy"] == "i2":
            case.update(metadata_ns=2, shootdown_ns=100)
        directory = run / name
        directory.mkdir()
        dump(directory / "config.json", case)
        stats = execute(common + [f"-replica-config={directory / 'config.json'}", f"-replica-plan={plan}"], directory)
        stats["case"] = name
        rows.append(stats)
        print(f"{name}: Passed; {stats['application_ps']/1e6:.3f} us, "
              f"copies={stats['copy_bytes']} B, faults={stats['copy_faults']}, "
              f"S3={stats['s3_preexisting_replica_read_transactions']}", flush=True)
    if args.workload == "probe" and args.probe_pages == 1 and args.replica_pages_per_gpu == 0:
        inv = next((s for s in rows if s["case"] == "inv_fault-900ns"), None)
        ideal = next((s for s in rows if s["case"] == "i1_fault-900ns"), None)
        copies = len(args.gpus.split(",")) - 1
        if inv and ideal and args.transfer_gran_bytes == 32:
            assert inv["copy_bytes"] == copies * 3 * args.page_bytes, inv
            assert ideal["copy_bytes"] == copies * (args.page_bytes + 96), ideal
            assert ideal["s3_preexisting_replica_read_transactions"] > 0
            assert ideal["s2_clean_transactions"] > 0
            assert ideal["copy_bytes"] < inv["copy_bytes"]
    dump(run / "summary.json", rows)
    text = ["case\tapplication_us\tkernel_us\tbarrier_us\trecovery_us\tcopy_bytes\tcopy_faults\tS3_reads\tpeak_pages\tevictions"]
    for s in rows:
        text.append("\t".join(str(x) for x in [s["case"], s["application_ps"]/1e6, s["kernel_ps"]/1e6,
                    s["barrier_flush_ps"]/1e6, s["recovery_wait_ps"]/1e6, s["copy_bytes"], s["copy_faults"],
                    s["s3_preexisting_replica_read_transactions"], s["peak_replica_pages"], s["evictions"]]))
    (run / "summary.tsv").write_text("\n".join(text) + "\n")
    print(f"Complete: {run / 'summary.tsv'}", flush=True)


if __name__ == "__main__":
    main()
