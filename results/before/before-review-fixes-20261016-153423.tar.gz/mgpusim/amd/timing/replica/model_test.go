package replica

import (
	"github.com/sarchlab/akita/v5/mem/vm"
	"github.com/sarchlab/akita/v5/timing"
	"testing"
)

func panics(t *testing.T, f func()) {
	t.Helper()
	defer func() {
		if recover() == nil {
			t.Error("expected rejection")
		}
	}()
	f()
}
func TestRejectDataRaceAndMultipleWriters(t *testing.T) {
	p := &Plan{Format: 1, PageBytes: 4096, SectorBytes: 32, Epochs: []Epoch{{Name: "race", Accesses: []Access{
		{Page: 4096, GPU: 1, Writes: []uint32{0}}, {Page: 4096, GPU: 2, Reads: []uint32{0}},
	}}}}
	panics(t, p.Validate)
	p.Epochs[0].Accesses[1].Reads = nil
	p.Epochs[0].Accesses[1].Writes = []uint32{1}
	panics(t, p.Validate)
	p.Epochs[0].Accesses[1].Writes = nil
	p.Epochs[0].Accesses[1].Reads = []uint32{1}
	p.Validate()
}
func TestFiniteFabricContentionAndSensitivity(t *testing.T) {
	c := DefaultConfig()
	c.BandwidthGBs = 1
	c.LinkNS = 5
	f := NewFabric(c)
	a := f.Reserve("GPU[1].RDMA.a", "GPU[2]", 100, 0)
	b := f.Reserve("GPU[1]", "GPU[3]", 100, 0)
	d := f.Reserve("GPU[4]", "GPU[5]", 100, 0)
	if a != 105000 || b != 205000 || d != a {
		t.Fatalf("contention not modeled: %d %d %d", a, b, d)
	}
	c.BandwidthGBs = 0
	g := NewFabric(c)
	if v := g.Reserve("GPU[1]", "GPU[2]", 1<<20, 0); v != 5000 {
		t.Fatal(v)
	}
}
func TestTransferGranularityAndExtents(t *testing.T) {
	m := map[uint32]bool{0: true, 1: true, 4: true}
	a := intervals(m, 32, 32)
	b := intervals(m, 32, 128)
	if a.Bytes != 96 || a.Extents != 2 || b.Bytes != 256 || b.Extents != 1 {
		t.Fatalf("bad ranges: %+v %+v", a, b)
	}
}
func TestSectorGuardRejectsStaleAndUnplannedReads(t *testing.T) {
	s := &Session{Config: DefaultConfig(), active: &Epoch{Accesses: []Access{{Page: 4096, GPU: 2, Reads: []uint32{0, 1}}}},
		mapped: map[[2]uint64]bool{{4096, 2}: true},
		pages: map[uint64]*pageState{4096: {Copies: map[int]*copyState{
			2: {Frame: 8192, Valid: map[uint32]bool{0: true}},
		}}},
	}
	s.guard(4096, 2, map[uint32]bool{0: true}, false)
	panics(t, func() { s.guard(4096, 2, map[uint32]bool{1: true}, false) })
	panics(t, func() { s.guard(4096, 2, map[uint32]bool{2: true}, false) })
}
func TestFaultInfinityDoesNotMakeFabricFree(t *testing.T) {
	c := DefaultConfig()
	c.FaultNS = 0
	f := NewFabric(c)
	if f.Reserve("GPU[1]", "GPU[2]", 4096, timing.VTimeInPicoSec(1000)) <= 1000 {
		t.Fatal("zero fault must preserve transfer time")
	}
}

func TestS3ShadowDoesNotResurrectEvictedReplica(t *testing.T) {
	c := DefaultConfig()
	c.ReplicaPagesPerGPU = 1
	s := &Session{Config: c, shadow: map[[2]uint64]bool{}, baselineValid: map[[2]uint64]bool{},
		pages: map[uint64]*pageState{4096: {Home: vm.Page{DeviceID: 1}}, 8192: {Home: vm.Page{DeviceID: 1}}}}
	e := Epoch{Accesses: []Access{{Page: 4096, GPU: 2, Reads: []uint32{1}}}}
	s.prepareShadow(e, map[uint64]int{})
	e.Accesses[0].Page = 8192
	s.prepareShadow(e, map[uint64]int{})
	if s.shadow[[2]uint64{4096, 2}] {
		t.Fatal("old copy should have been evicted")
	}
	e.Accesses[0].Page = 4096
	s.baselineValid = map[[2]uint64]bool{}
	s.prepareShadow(e, map[uint64]int{4096: 1})
	if s.baselineValid[[2]uint64{4096, 2}] || s.Stats.S4Targets != 0 {
		t.Fatal("evicted copy counted as S3/S4 target")
	}
}
