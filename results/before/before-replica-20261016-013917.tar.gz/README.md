# MGPUSim UVM 映射缺页基线

后续工作目录：`/home/only/projects/mgpusim-uvm`。
Go 模块目录：`/home/only/projects/mgpusim-uvm/mgpusim`。

## 运行

```bash
cd /home/only/projects/mgpusim-uvm/mgpusim
export PATH=/usr/local/go/bin:/home/only/go/bin:$PATH
bash experiments/fault-baseline/run.sh
```

上面的入口重新编译并运行两/四 GPU 数值、缺页、有限队列、反压和远端 RDMA 检查。
输出保存在旁边的 `results/uvm-validation-<时间>/`，每轮使用独立目录。

单独运行 FIR：

```bash
cd /home/only/projects/mgpusim-uvm/mgpusim
/usr/local/go/bin/go build -o /tmp/mgpu-uvm-fir ./amd/samples/fir
/tmp/mgpu-uvm-fir -timing -verify -disable-rtm -gpus=1,2,3,4 \
  -use-unified-memory -vm-mode=demand -length=4096 -report-all \
  -metric-file-name=/tmp/mgpu-uvm-fir
```

## 当前模型

`-vm-mode=demand`：L1/L2 TLB → 每 GPU 本地 GMMU → 必要时共享 HostMMU → 本地安装映射。
统一内存页面的映射初始不在 GPU 本地页表；普通显存、代码和参数的映射仍预装。
同 GPU 同页请求合并；主机服务槽和队列有限，包含排队与反压。
数据位置固定，统一内存分配器把数据放在 GPU 1，其他 GPU 通过 RDMA 远端访问。
此模型不实现迁移、复制、显存驱逐、再次缺页或多级 PTE 的真实内存请求。

`-vm-mode=shared` 保留上游兼容路径，也是未指定 VM 模式时的默认值。
研究映射缺页时明确传入 `-timing -vm-mode=demand -use-unified-memory`，
通过 `-gpus` 选择独立 GPU，不与 `-unified-gpus` 混用。

理想映射模式、早期理想页表开关、L3 TLB、LIBRA 容量配置及访存 trace/副本恢复扩展已移除。
原有可视化与 Akita 性能统计仍可使用。

## 保留的正确性修复

- 驱动在数据拷贝和全部 GPU cache flush 回复都完成后再完成拷贝命令，修复回复顺序导致的停滞。
- Command Processor 保留 cache drain/flush/invalidate 与 kernel 边界处理的修复。
- `akita-patched` 保留地址空间范围和远端端口，使 L1 对其他 GPU 内存的访问正确进入 RDMA。
- 通过 `localmapping` 的固定放置保护，拒绝开始翻译后的直接 remap/free，避免旧 TLB 映射。

`mgpusim/go.mod` 的本地 Akita 替换是这些修复的一部分；两个目录需要放在一起。

## 开发检查

```bash
cd /home/only/projects/mgpusim-uvm/mgpusim
export PATH=/usr/local/go/bin:/home/only/go/bin:$PATH
go build ./...
go test -race -p 2 ./amd/timing/localmapping ./amd/timing/faultvm ./amd/driver \
  ./amd/timing/cp ./amd/timing/cu ./amd/samples/runner/...
golangci-lint run ./... --timeout=10m
```

模型参数和指标见 `mgpusim/experiments/fault-baseline/README.md`。
本次验证记录见 `VALIDATION.md`。本目录当前不含 Git 元数据。
