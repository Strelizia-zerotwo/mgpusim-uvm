package runner

import (
	"github.com/sarchlab/akita/v5/tracing"
	"github.com/tebeka/atexit"
)

// instTracer can trace the number of instruction completed.
type instTracer struct {
	tracing.NopTracer

	count     uint64
	simdCount uint64
	maxCount  uint64

	inflightInst map[uint64]tracing.TaskStart
}

// newInstTracer creates a tracer that can count the number of instructions.
func newInstTracer() *instTracer {
	t := &instTracer{
		inflightInst: map[uint64]tracing.TaskStart{},
	}
	return t
}

// newInstStopper with stop the execution after a given number of instructions
// is retired.
func newInstStopper(maxInst uint64) *instTracer {
	t := &instTracer{
		maxCount:     maxInst,
		inflightInst: map[uint64]tracing.TaskStart{},
	}
	return t
}

func (t *instTracer) StartTask(task tracing.TaskStart) {
	if task.Kind != "inst" {
		return
	}

	t.inflightInst[task.ID] = task
}

func (t *instTracer) EndTask(task tracing.TaskEnd) {
	orgTask, found := t.inflightInst[task.ID]
	if !found {
		return
	}

	if orgTask.What == "VALU" {
		t.simdCount++
	}

	delete(t.inflightInst, task.ID)

	t.count++

	if t.maxCount > 0 && t.count >= t.maxCount {
		atexit.Exit(0)
	}
}
