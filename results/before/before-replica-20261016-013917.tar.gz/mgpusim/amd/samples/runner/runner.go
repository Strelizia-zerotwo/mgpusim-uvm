// Package runner defines how default benchmark samples are executed.
package runner

import (
	"log"

	// Enable profiling
	_ "net/http/pprof"
	"sync"

	"github.com/sarchlab/akita/v5/simulation"
	"github.com/sarchlab/akita/v5/timing"
	"github.com/sarchlab/mgpusim/v5/amd/arch"
	"github.com/sarchlab/mgpusim/v5/amd/benchmarks"
	"github.com/sarchlab/mgpusim/v5/amd/driver"
	"github.com/sarchlab/mgpusim/v5/amd/samples/runner/emusystem"
	"github.com/sarchlab/mgpusim/v5/amd/samples/runner/timingconfig"
	"github.com/sarchlab/mgpusim/v5/amd/sampling"
)

type verificationPreEnablingBenchmark interface {
	benchmarks.Benchmark

	EnableVerification()
}

// Runner is a class that helps running the benchmarks in the official samples.
type Runner struct {
	simulation *simulation.Simulation
	gpuDriver  *driver.Driver
	reporter   *reporter

	Timing           bool
	Verify           bool
	Parallel         bool
	UseUnifiedMemory bool
	ArchType         arch.Type
	GPUType          string

	GPUIDs     []int
	benchmarks []benchmarks.Benchmark
}

// Init initializes the platform simulate
func (r *Runner) Init() *Runner {
	r.parseFlag()
	r.validateFaultFlags()
	if !r.Timing && *mmuReportFlag {
		panic("-report-mmu requires -timing")
	}

	log.SetFlags(log.Llongfile | log.Ldate | log.Ltime)

	r.initSimulation()

	if r.Timing {
		r.buildTimingPlatform()
	} else {
		r.buildEmuPlatform()
	}

	r.createUnifiedGPUs()

	return r
}

func (r *Runner) initSimulation() {
	builder := simulation.MakeBuilder()

	if *parallelFlag {
		builder = builder.WithParallelEngine()
	}

	if *disableAkitaRTM {
		builder = builder.WithoutMonitoring()
	} else if *customPortForAkitaRTM > 0 {
		builder = builder.WithMonitorPort(*customPortForAkitaRTM)
	}

	if *visTracing {
		builder = builder.WithVisTracingOnStart()
		builder = withRecordedSource(builder)
	}

	// Only honor -metric-file-name when it is explicitly set, so the
	// default output name stays the v4-compatible "akita_sim_<id>".
	if metricFileNameFlagIsSet() {
		builder = builder.WithOutputFileName(*filenameFlag)
	}

	r.simulation = builder.Build()
}

func (r *Runner) buildEmuPlatform() {
	b := emusystem.MakeBuilder().
		WithSimulation(r.simulation).
		WithNumGPUs(r.GPUIDs[len(r.GPUIDs)-1]).
		WithArchitecture(r.ArchType)

	if *isaDebug {
		b = b.WithDebugISA()
	}

	r.gpuDriver = b.Build()
}

func (r *Runner) buildTimingPlatform() {
	sampling.InitSampledEngine()

	b := timingconfig.MakeBuilder().
		WithSimulation(r.simulation).
		WithNumGPUs(r.GPUIDs[len(r.GPUIDs)-1]).
		WithGPUType(r.GPUType)

	if *vmModeFlag != "shared" {
		b = b.WithFaultVM(*vmModeFlag, faultConfigFromFlags())
	}

	if *magicMemoryCopy {
		b = b.WithMagicMemoryCopy()
	}

	r.gpuDriver = b.Build()
	r.reporter = newReporter(r.simulation)
}

func (r *Runner) createUnifiedGPUs() {
	if *unifiedGPUFlag == "" {
		return
	}

	unifiedGPUID := r.gpuDriver.CreateUnifiedGPU(nil, r.GPUIDs)
	r.GPUIDs = []int{unifiedGPUID}
}

// AddBenchmark adds an benchmark that the driver runs
func (r *Runner) AddBenchmark(b benchmarks.Benchmark) {
	b.SelectGPU(r.GPUIDs)
	if r.UseUnifiedMemory {
		b.SetUnifiedMemory()
	}

	r.benchmarks = append(r.benchmarks, b)
}

// AddBenchmarkWithoutSettingGPUsToUse allows for user specified GPUs for
// the benchmark to run.
func (r *Runner) AddBenchmarkWithoutSettingGPUsToUse(b benchmarks.Benchmark) {
	if r.UseUnifiedMemory {
		b.SetUnifiedMemory()
	}

	r.benchmarks = append(r.benchmarks, b)
}

// Run runs the benchmark
func (r *Runner) Run() {
	r.Driver().Run()

	var wg sync.WaitGroup
	for _, b := range r.benchmarks {
		wg.Add(1)
		go func(b benchmarks.Benchmark, wg *sync.WaitGroup) {
			if r.Verify {
				if b, ok := b.(verificationPreEnablingBenchmark); ok {
					b.EnableVerification()
				}
			}

			b.Run()

			if r.Verify {
				b.Verify()
			}
			wg.Done()
		}(b, &wg)
	}
	wg.Wait()

	// The benchmark goroutines return as soon as their kernels report
	// completion, but the driver runs the Akita engine on a background
	// goroutine that may still be draining the final events (including the
	// trailing tracing EndTask hooks). Wait for that goroutine to go idle
	// before reading any results, otherwise report() races it and
	// order-sensitive metrics (e.g. cache req_average_latency) come out
	// non-deterministic.
	r.Driver().WaitForEngineIdle()

	if r.reporter != nil {
		r.reporter.report()
		r.reporter.dataRecorder.Flush()
	}

	r.Driver().Terminate()
	r.simulation.Terminate()
}

// Driver returns the GPU driver used by the current runner.
func (r *Runner) Driver() *driver.Driver {
	return r.gpuDriver
}

// Engine returns the event-driven simulation engine used by the current runner.
func (r *Runner) Engine() timing.Engine {
	return r.simulation.GetEngine()
}
